#define VERSION_NO "0.57"
#define VERSION_DATE "20090913"

#define VITETRIS_VER "vitetris "VERSION_NO
